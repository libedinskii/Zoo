public interface ZooKeeper {
    void feedAnimal(Animal animal);
    void cleanEnclosure(Animal animal);
}
